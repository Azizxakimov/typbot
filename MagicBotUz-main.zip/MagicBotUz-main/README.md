# MagicBotUz
$ apt update


$ apt upgrade


$ pkg install git


$ pkg install python


$ pip install telethon


$ git clone https://github.com/darknetUzb/MagicBotUz


$ cd MagicBotUz


$ python magicbot



Tutorial: https://t.me/magic_uz_bot
